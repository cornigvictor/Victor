// Handle form submission
document.addEventListener('DOMContentLoaded', function() {
  const signupForm = document.getElementById('signup-form');

  // Check if user is already signed up (for demonstration purposes)
  // In a real app, you'd check this with backend logic
  const isUserSignedUp = localStorage.getItem('isSignedUp');

  if (isUserSignedUp) {
    // Redirect to profile page if already signed up
    window.location.href = 'profile.html';
  }

  // Form submit event listener
  signupForm.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Get form data
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Basic validation
    if (username && email && password) {
      // Save user sign-up status
      localStorage.setItem('isSignedUp', true);

      // Redirect to profile page
      window.location.href = 'profile.html';
    } else {
      alert('Please fill in all fields.');
    }
  });
});
